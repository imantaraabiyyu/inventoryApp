import React,{Component} from 'react';
import Header from '../../component/Header'


class Items extends Component{
    render(){
        return(
            <div>
                <Header />
                <span>This is Items Page</span>
             </div>
        );
    }
}
export default Items;