import React,{Component} from 'react';
import Header from '../../component/Header'


class Stocks extends Component{
    render(){
        return(
            <div>
                <Header />
                <span>This is Stocks Page</span>
             </div>
        );
    }
}
export default Stocks;