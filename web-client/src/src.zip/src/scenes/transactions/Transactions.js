import React,{Component} from 'react';
import {Typography} from '@material-ui/core';
import {withStyles} from '@material-ui/core/styles';
import Page from '../../component/Page'
import styles from './styles.js';


class Transactions extends Component {
  
    render() {
      return (
       <Page>
           <Typography>
               <span> This is Transactions Page</span>
           </Typography>
       </Page>
      );
    }
  }

export default withStyles(styles,{withTheme:true})(Transactions);