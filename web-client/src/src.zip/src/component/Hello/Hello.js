import React,{Component} from 'react';
import './Hello.css';

class Hello extends React.Component{
    render(){
        return(
        <div className="hello-div">Hello,{this.props.name}</div>
        );
    }
}
export default Hello;