const drawerWidth = 240;

const styles = theme => ({

        toolbar: theme.mixins.toolbar,
        drawerPaper: {
        width: drawerWidth,
    },
    drawer: {
        [theme.breakpoints.up('sm')]: {
        width: drawerWidth,
        flexShrink: 0,
        },
    }
});

export default styles;