import React,{Component} from 'react';
import {withStyles} from '@material-ui/core/styles'
import Header from '../Page';
import Navigation from '../Navigation';
import styles from './styles.js';


class Page extends Component{
    constructor(props){
        super(props);

    this.state={
        drawerOpen:false
    }
    }
  handleDrawerToggle=() => {
    this.setState({drawerOpen: !this.state.drawerOpen})
  }
    render() {
        const {children,classes} = this.props;

      return (
       <div className={classes.root}>
           <csBaseLine/>
         <Header onMenuClick={this.handleDrawerToggle}/>
         <Navigation mobileOpen={this.state.drawerOpen} handleDrawerToggle={this.handleDrawerToggle} />
         <main className={classes.content}>
         <div className={classes.toolbar}/>
         {children}
         </main>
       </div>
      );
    }
  }

export default withStyles(styles,{withTheme:true})(Page);