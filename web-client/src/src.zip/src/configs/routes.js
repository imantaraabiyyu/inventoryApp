import Transactions from '../scenes/transactions';
import Items from '../scenes/items';
import Stocks from '../scenes/stocks';
import Units from '../scenes/units';


const routes =[
    {
      path: '/',
      component:Transactions,
      exact : true 
    },
    {
      path: '/items',
      component:Items
    },
    {
      path: '/stocks',
      component:Stocks
    },
    {
      path: '/units',
      component:Units
    }
  ];
export default routes;