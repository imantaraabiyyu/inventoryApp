import React, { Component } from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import Error from './scenes/error'
import routes from './configs/routes'
import './App.css';

class App extends Component{

  render(){
  return (
    <Router>
          <Switch>
          {routes.map((route,index) =>
            <Route 
            key={index}
            path={route.path} 
            component={route.component} 
            exact={route.exact}/>
            )}
          <Route>
          <Error code={404}/>
          </Route>
          </Switch>
      </Router>
  );
}
}

export default App;